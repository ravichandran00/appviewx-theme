<?php wp_footer(); ?>

<footer class="appviewx-footer">
    <div class="appviewx-footer-top">

        <div class="appviewx-footer-left">
            <?php
    $footer_logo = get_theme_mod('appviewx_footer_logo');
    $header_logo = get_theme_mod('appviewx_logo');

    if ($footer_logo) {
      echo '<a href="' . esc_url(home_url('/')) . '">
              <img src="' . esc_url($footer_logo) . '" alt="Footer Logo" class="appviewx-footer-logo" />
            </a>';
    } elseif ($header_logo) {
      echo '<a href="' . esc_url(home_url('/')) . '">
              <img src="' . esc_url($header_logo) . '" alt="Site Logo" class="appviewx-footer-logo" />
            </a>';
    } else {
      echo '<a href="' . esc_url(home_url('/')) . '" class="appviewx-footer-site-name">'
           . get_bloginfo('name') .
           '</a>';
    }
  ?>

            <p class="appviewx-footer-desc">
                <?php
      echo esc_html(
        get_theme_mod('appviewx_footer_description') ?: 
        'Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage,'
      );
    ?>
            </p>
        </div>

        <div class="appviewx-footer-right">
            <h4 class="appviewx-footer-heading">Quick Links</h4>
            <?php
    if (has_nav_menu('primary')) {
      wp_nav_menu([
        'theme_location' => 'primary', 
        'menu_class'     => 'appviewx-footer-menu',
        'container'      => false,
        'depth'          => 1, 
      ]);
    } else {
      echo '<p>Please assign a Primary Menu in Appearance → Menus.</p>';
    }
  ?>
        </div>
    </div>
    <div class="appviewx-footer-bottom">
        <p class="appviewx-footer-text">
            <?php
      echo esc_html(
        get_theme_mod('appviewx_footer_text') ? get_theme_mod('appviewx_footer_text') :
        '© ' . date('Y') . ' ' . get_bloginfo('name') . '. All rights reserved.'
      );
    ?>
        </p>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
    AOS.init({
    once: true,
    duration: 800, 
    easing: 'ease-in-out',
});
</script>
</body>
</html>