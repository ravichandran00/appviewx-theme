    // Mobile Menu Toggle
     document.addEventListener("DOMContentLoaded", function() {
        const toggle = document.getElementById('menu-toggle');
        const menu = document.getElementById('mobile-menu');
        toggle.addEventListener('click', () => {
            menu.classList.toggle('hidden');
        });
    });


    // Theme Toggle
    document.addEventListener("DOMContentLoaded", () => {
        const root = document.documentElement;

        const toggles = [{
                wrapper: 'appviewx-theme-toggle',
                knob: 'appviewx-toggle-knob'
            },
            {
                wrapper: 'appviewx-theme-toggle-mobile',
                knob: 'appviewx-toggle-knob-mobile'
            }
        ];

        const setMode = (mode) => {
            if (mode === 'dark') {
                root.classList.add('dark');
                toggles.forEach(t => {
                    const wrapper = document.getElementById(t.wrapper);
                    const knob = document.getElementById(t.knob);
                    if (wrapper) wrapper.classList.remove('appviewx-day');
                    if (knob) knob.classList.remove('appviewx-sun');
                });
            } else {
                root.classList.remove('dark');
                toggles.forEach(t => {
                    const wrapper = document.getElementById(t.wrapper);
                    const knob = document.getElementById(t.knob);
                    if (wrapper) wrapper.classList.add('appviewx-day');
                    if (knob) knob.classList.add('appviewx-sun');
                });
            }
            localStorage.setItem('appviewx-theme', mode);
        };

        const saved = localStorage.getItem('appviewx-theme') || 'dark';
        setMode(saved);

        toggles.forEach(t => {
            const btn = document.getElementById(t.wrapper);
            btn?.addEventListener('click', () => {
                const isDark = root.classList.contains('dark');
                setMode(isDark ? 'light' : 'dark');
            });
        });
    });

 //Submenu Toggle for Mobile
 document.addEventListener('DOMContentLoaded', () => {
        const isMobile = window.innerWidth < 768;
        if (isMobile) {
            const menuItems = document.querySelectorAll('#mobile-menu li.menu-item-has-children');

            menuItems.forEach(item => {
                const submenu = item.querySelector('ul');
                if (submenu) {
                    submenu.classList.add('hidden'); 

                    item.addEventListener('click', (e) => {
                        e.stopPropagation();
                        e.preventDefault();

                        submenu.classList.toggle('hidden');
                    });
                }
            });
        }
    });