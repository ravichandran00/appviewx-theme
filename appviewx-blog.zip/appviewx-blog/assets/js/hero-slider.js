document.addEventListener("DOMContentLoaded", () => {
  const slides = document.querySelectorAll(".appviewx-slide");
  const dots = document.querySelectorAll(".appviewx-dot");
  const prevBtn = document.querySelector(".appviewx-prev-arrow");
  const nextBtn = document.querySelector(".appviewx-next-arrow");

  let currentIndex = 0;
  let direction = 1;
  let autoSlideInterval;

  function updateSlides() {
    slides.forEach((slide, i) => {
      slide.classList.remove("active", "exit-left", "exit-right");
      if (i === currentIndex) {
        slide.classList.add("active");
      } else if (i < currentIndex) {
        slide.classList.add("exit-left");
      } else {
        slide.classList.add("exit-right");
      }
    });

    dots.forEach((dot, i) => {
      dot.classList.toggle("active", i === currentIndex);
    });
  }

  function goToSlide(index) {
    direction = index > currentIndex ? 1 : -1;
    currentIndex = index;
    updateSlides();
  }

  function nextSlide() {
    direction = 1;
    currentIndex = (currentIndex + 1) % slides.length;
    updateSlides();
  }

  function prevSlide() {
    direction = -1;
    currentIndex = (currentIndex - 1 + slides.length) % slides.length;
    updateSlides();
  }

 
  nextBtn?.addEventListener("click", nextSlide);
  prevBtn?.addEventListener("click", prevSlide);

  dots.forEach((dot, i) => {
    dot.addEventListener("click", () => goToSlide(i));
  });

  // Auto Slide
  function startAutoSlide() {
    autoSlideInterval = setInterval(nextSlide, 6000);
  }

  function stopAutoSlide() {
    clearInterval(autoSlideInterval);
  }


  const carousel = document.querySelector(".appviewx-carousel");
  carousel?.addEventListener("mouseover", stopAutoSlide);
  carousel?.addEventListener("mouseout", startAutoSlide);


  updateSlides();
  startAutoSlide();
});
