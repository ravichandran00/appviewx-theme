<?php get_header(); ?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

  <section class="appviewx-single-banner" style="background-image: url('<?php echo get_the_post_thumbnail_url(get_the_ID(), 'full'); ?>');" >
    <div class="appviewx-single-banner-overlay">
      <div class="appviewx-single-meta">
        <span class="appviewx-single-author"><?php echo get_the_author(); ?></span> •
        <span class="appviewx-single-date"><?php echo get_the_date(); ?></span>
      </div>
    </div>
  </section>

  <main class="appviewx-single-wrapper">
    <div class="appviewx-single-container" data-aos="fade-up">
      <h1 class="appviewx-single-title"><?php the_title(); ?></h1>

      <div class="appviewx-single-content">
        <?php the_content(); ?>
      </div>
    </div>
  </main>

<?php endwhile; endif; ?>

<?php get_footer(); ?>
