<div class="appviewx-carousel-section">
 

  <div class="appviewx-carousel" id="appviewx-carousel">
    <?php
    $query = new WP_Query([
      'post_type' => 'post',
      'posts_per_page' => 3,
    ]);
    if ($query->have_posts()) :
      $index = 0;
      while ($query->have_posts()) : $query->the_post();
        $featured_img = get_the_post_thumbnail_url(get_the_ID(), 'full');
        $author = get_the_author();
        $date = get_the_date();
        $read_time = '5 min'; 
        ?>
        <div class="appviewx-slide <?php echo $index === 0 ? 'active' : ''; ?>" style="background-image: url('<?php echo esc_url($featured_img); ?>');">
          <div class="appviewx-overlay"></div>
          <div class="appviewx-slide-content">
            <h1>
              <a href="<?php the_permalink(); ?>" class="appviewx-slide-title"><?php the_title(); ?></a>
            </h1>
            <p class="appviewx-slide-excerpt"><?php echo wp_trim_words(get_the_excerpt(), 20); ?></p>
            <div class="appviewx-slide-meta">
              <?php echo esc_html($author); ?> • <?php echo esc_html($date); ?> • <?php echo $read_time; ?>
            </div>
          </div>
        </div>
        <?php $index++;
      endwhile;
      wp_reset_postdata();
    endif;
    ?>
  </div>

  <!-- Navigation Controls -->
  <div class="appviewx-carousel-controls">
    <!-- Dots -->
    <div class="appviewx-dots">
      <?php for ($i = 0; $i < $index; $i++) : ?>
        <div class="appviewx-dot <?php echo $i === 0 ? 'active' : ''; ?>" data-slide="<?php echo $i; ?>"></div>
      <?php endfor; ?>
    </div>

    <!-- Arrows -->
    <div class="appviewx-arrows">
      <button class="appviewx-arrow-btn appviewx-prev-arrow">&#10094;</button>
      <button class="appviewx-arrow-btn appviewx-next-arrow">&#10095;</button>
    </div>
  </div>

</div>
