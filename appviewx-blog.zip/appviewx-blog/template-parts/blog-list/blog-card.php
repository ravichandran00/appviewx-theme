<article class="appviewx-blog-card" data-aos="fade-up">
    <a href="<?php the_permalink(); ?>" class="appviewx-card-thumb">
        <?php if (has_post_thumbnail()) : ?>
        <?php the_post_thumbnail('medium_large'); ?>
        <?php else : ?>
        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/placeholder.jpg" alt="No image" />
        <?php endif; ?>
    </a>

    <div class="appviewx-card-content">
        <div class="appviewx-card-category">
            <?php
      $cats = get_the_category();
      if (!empty($cats)) {
        echo esc_html($cats[0]->name);
      }
      ?>
        </div>
        <h2 class="appviewx-card-title">
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </h2>
        <p class="appviewx-card-excerpt">
            <?php echo wp_trim_words(get_the_excerpt(), 20); ?>
        </p>
        <div class="appviewx-card-meta">
            <?php echo get_the_date(); ?>
        </div>
    </div>
</article>