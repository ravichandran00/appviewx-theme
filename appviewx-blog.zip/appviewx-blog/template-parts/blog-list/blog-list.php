<section class="appviewx-blog-list-section">
    <h2 class="appviewx-blog-section-title" data-aos="zoom-in">Latest Blog Posts</h2>

    <div class="appviewx-blog-grid">
        <?php
    $latest_posts = new WP_Query([
      'post_type' => 'post',
      'posts_per_page' => 5,
    ]);

    if ($latest_posts->have_posts()) :
      while ($latest_posts->have_posts()) : $latest_posts->the_post();
        get_template_part('template-parts/blog-list/blog-card');
      endwhile;
      wp_reset_postdata();
    else :
      echo '<p>No blog posts found.</p>';
    endif;
    ?>
    </div>
</section>