<?php get_header(); ?>

<main class="container py-10">
  <?php
    if (have_posts()) :
      while (have_posts()) : the_post();
        the_title('<h1 class="text-3xl font-bold mb-4">', '</h1>');
        the_content();
      endwhile;
    endif;
  ?>
</main>

<?php get_footer(); ?>
