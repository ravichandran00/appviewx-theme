<?php
get_header();
get_template_part('template-parts/hero-slider/hero-slider');
get_template_part('template-parts/blog-list/blog-list'); 
get_footer();
