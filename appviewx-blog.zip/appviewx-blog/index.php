<?php get_header(); ?>

<main class="container py-10">
  <h1 class="text-2xl font-bold">Default Index Page</h1>
  <p>This is the index fallback template.</p>
</main>

<?php get_footer(); ?>
