<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <!-- AOS for scroll animations -->
    <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?> class="bg-white text-gray-900 transition-colors duration-300">

    <header class="sticky top-0 z-50 bg-white dark:bg-gray-900 shadow-md transition-colors duration-300">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <div>
                <?php if (get_theme_mod('appviewx_logo')) : ?>
                <a href="<?php echo esc_url(home_url('/')); ?>">
                    <img src="<?php echo esc_url(get_theme_mod('appviewx_logo')); ?>" alt="Site Logo"
                        class="h-10 w-auto">
                </a>
                <?php else : ?>
                <a href="<?php echo esc_url(home_url('/')); ?>" class="text-xl font-bold text-gray-800 dark:text-white">
                    <?php bloginfo('name'); ?>
                </a>
                <?php endif; ?>
            </div>

            <!-- Desktop Menu -->
            <div class="flex items-center space-x-4">
                <nav class="hidden md:block">
                    <?php
          wp_nav_menu(array(
            'theme_location' => 'primary',
            'container' => false,
            'menu_class' => 'flex space-x-6 list-none appviewx-menu',
            'fallback_cb' => false,
          ));
        ?>
                </nav>

                <!-- AppViewX Dark/Light Toggle -->
                <div class="appviewx-toggle-wrapper hidden md:block">
                    <div class="appviewx-toggle" id="appviewx-theme-toggle">
                        <div class="appviewx-toggle-knob" id="appviewx-toggle-knob"></div>
                    </div>
                </div>

                <!-- Mobile Toggle -->
                <button id="menu-toggle" class="text-2xl md:hidden focus:outline-none">☰</button>
            </div>
        </div>

        <!-- Mobile Menu -->
        <div id="mobile-menu" class="md:hidden hidden px-4 pb-4">
            <?php
      wp_nav_menu(array(
        'theme_location' => 'primary',
        'container' => false,
        'menu_class' => 'space-y-2 list-none ',
        'fallback_cb' => false
      ));
    ?>

            <!-- Dark Mode Toggle (Mobile) -->
            <div class="mt-4 md:hidden">
                <div class="appviewx-toggle" id="appviewx-theme-toggle-mobile">
                    <div class="appviewx-toggle-knob" id="appviewx-toggle-knob-mobile"></div>
                </div>
            </div>
        </div>
    </header>
    <?php wp_body_open(); ?>