<?php
function appviewx_enqueue_scripts() {
    wp_enqueue_style('appviewx-style', get_template_directory_uri() . '/assets/css/style.css');
    wp_enqueue_script('appviewx-hero-slider', get_template_directory_uri() . '/assets/js/hero-slider.js', array(), null, true);
     wp_enqueue_script('appviewx-header', get_template_directory_uri() . '/assets/js/header.js', array(), null, true);
    wp_enqueue_script('jquery');
 
}
add_action('wp_enqueue_scripts', 'appviewx_enqueue_scripts');



function appviewx_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'appviewx-blog')
    ));
}
add_action('after_setup_theme', 'appviewx_theme_setup');

require get_template_directory() . '/inc/theme-functions.php';

function appviewx_customize_register($wp_customize) {
   
    $wp_customize->add_setting('appviewx_logo');
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'appviewx_logo', array(
        'label' => __('Site Logo', 'appviewx-blog'),
        'section' => 'title_tagline',
        'settings' => 'appviewx_logo',
    )));

}
add_action('customize_register', 'appviewx_customize_register');

class AppViewX_Walker_Nav_Menu extends Walker_Nav_Menu {
  function start_lvl(&$output, $depth = 0, $args = null) {
    $indent = str_repeat("\t", $depth);
    $output .= "\n$indent<ul class=\"absolute left-0 mt-2 w-48 bg-white shadow-lg rounded-md hidden group-hover:block z-50\">\n";
  }

  function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
    $classes = empty($item->classes) ? [] : (array) $item->classes;
    $has_children = in_array('menu-item-has-children', $classes);
    $class_names = join(' ', array_filter($classes));

    $output .= "<li class=\"relative group transition duration-300 ease-in-out\">";
    $output .= '<a href="' . esc_attr($item->url) . '" class="block px-4 py-2 hover:bg-gray-100">' . $item->title . '</a>';
  }

  function end_el(&$output, $item, $depth = 0, $args = null) {
    $output .= "</li>\n";
  }

  function end_lvl(&$output, $depth = 0, $args = null) {
    $output .= "</ul>\n";
  }
}
function appviewx_register_menus() {
  register_nav_menus([
    'footer_menu' => __('Footer Quick Links Menu', 'appviewx'),
  ]);
}
add_action('after_setup_theme', 'appviewx_register_menus');

function appviewx_customize_footer_content($wp_customize) {
  
  $wp_customize->add_section('appviewx_footer_section', array(
    'title'    => __('Footer Settings', 'appviewx'),
    'priority' => 160,
  ));

  
  $wp_customize->add_setting('appviewx_footer_description', array(
    'default' => 'We share insights on technology, innovation, and the digital world. Stay inspired and stay informed!',
    'sanitize_callback' => 'sanitize_textarea_field',
  ));

  $wp_customize->add_control('appviewx_footer_description', array(
    'label'       => __('Footer Description', 'appviewx'),
    'section'     => 'appviewx_footer_section',
    'type'        => 'textarea',
  ));

  
  $wp_customize->add_setting('appviewx_footer_text', array(
    'default' => '© ' . date('Y') . ' ' . get_bloginfo('name') . '. All rights reserved.',
    'sanitize_callback' => 'sanitize_text_field',
  ));

  $wp_customize->add_control('appviewx_footer_text', array(
    'label'   => __('Footer Copyright', 'appviewx'),
    'section' => 'appviewx_footer_section',
    'type'    => 'text',
  ));
}
add_action('customize_register', 'appviewx_customize_footer_content');